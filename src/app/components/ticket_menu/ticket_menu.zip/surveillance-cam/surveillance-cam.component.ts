import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-surveillance-cam',
  templateUrl: './surveillance-cam.component.html',
  styleUrls: ['./surveillance-cam.component.scss'],
})
export class SurveillanceCamComponent implements OnInit {

  constructor( private modal: ModalController) { }

  ngOnInit() {}

  dismissModal() {
    if (this.modal) {
      this.modal.dismiss().then(() => { this.modal = null; });
    }
}
}
