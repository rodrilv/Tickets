import { Component, OnInit } from '@angular/core';
//import { LoginService } from '../services/login.service';
import { ModalController } from '@ionic/angular';


@Component({
  selector: 'app-wifi',
  templateUrl: './wifi.component.html',
  styleUrls: ['./wifi.component.scss'],
})
export class WifiComponent implements OnInit {
  constructor( 
    private modal: ModalController
  ) { }

  ngOnInit() {}

  dismissModal() {
    if (this.modal) {
      this.modal.dismiss().then(() => { this.modal = null; });
    }
}
}
